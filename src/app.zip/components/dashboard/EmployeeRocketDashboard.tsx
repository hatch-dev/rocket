"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { RocketHeader } from "@/components/rocket/Header";
import { RocketSidebar } from "@/components/rocket/Sidebar";
import { RocketCard } from "@/components/rocket/Card";
import { RocketChatWidget } from "@/components/rocket/ChatWidget";

export function EmployeeRocketDashboard({ clients, employee }: any) {

  // ================= STATE =================
  const [activeClient, setActiveClient] = useState(clients?.[0]?.id);
  const [tools, setTools] = useState<any[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);

  // ================= FETCH TOOLS =================
  useEffect(() => {
    if (!activeClient) return;

    fetch(`/api/employees/tools?clientId=${activeClient}`)
      .then(res => res.json())
      .then(data => {
        console.log("TOOLS:", data);
        
        setTools(data);

      })
      .catch(err => console.log("TOOLS ERROR:", err));

  }, [activeClient]);

  // ================= FAVORITE =================
  const toggleFavorite = (tool: any) => {
    const exists = favorites.find((f) => f.id === tool.id);

    if (exists) {
      setFavorites(favorites.filter((f) => f.id !== tool.id));
    } else {
      setFavorites([...favorites, tool]);
    }
  };

  const isFavorite = (id: number) => {
    return favorites.some((f) => f.id === id);
  };

  return (
    <>
      <RocketHeader employee={employee} />

      <div className="wrapper">

        {/* ================= SIDEBAR ================= */}
        <RocketSidebar
          clients={clients}
          employee={employee}
          activeClient={activeClient}
          setActiveClient={setActiveClient}
        />

        {/* ================= CONTENT ================= */}
        <div className="content-employee">

          <div className="title">Velkommen til Rocket!</div>
          <div className="subtitle">
            Velg en kunde under for raske snarveier.
          </div>

          {/* ================= TOOLS ================= */}
          <div className="grid">
            {tools.map((group: any) => (
              <RocketCard key={group.title} title={group.title}>

                {group.links.map((link: any) => (
                  <Link key={link.id} href={link.url} target="_blank">

                    <div className="item" style={{ position: "relative" }}>

                      <img src={link.icon} alt="" />
                      {link.title}

                      <span
                        style={{
                          position: "absolute",
                          right: 10,
                          top: 8,
                          cursor: "pointer",
                          fontSize: "16px"
                        }}
                        onClick={(e) => {
                          e.preventDefault();
                          toggleFavorite(link);
                        }}
                      >
                        {isFavorite(link.id) ? "★" : "☆"}
                      </span>

                    </div>

                  </Link>
                ))}

              </RocketCard>
            ))}
          </div>


        </div>

        <RocketChatWidget />
      </div>
    </>
  );
}
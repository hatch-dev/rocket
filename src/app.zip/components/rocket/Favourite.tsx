"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { RocketHeader } from "@/components/rocket/Header";
import { RocketSidebar } from "@/components/rocket/Sidebar";

export function Favourite({ clients, employee }: any) {

  // ================= STATE =================
  const [activeClient, setActiveClient] = useState(clients?.[0]?.id);
  const [tools, setTools] = useState<any[]>([]);

  // ================= FETCH TOOLS =================
  useEffect(() => {
    if (!activeClient) return;

    fetch(`/api/employees/tools?clientId=${activeClient}`)
      .then(res => res.json())
      .then(data => {
        console.log("TOOLS:", data);
        
        setTools(data);

      })
      .catch(err => console.log("TOOLS ERROR:", err));

  }, [activeClient]);

  return (
    <>
      <RocketHeader employee={employee} />

      <div className="wrapper">

        {/* ================= SIDEBAR ================= */}
        <RocketSidebar
          clients={clients}
          employee={employee}
          activeClient={activeClient}
          setActiveClient={setActiveClient}
        />

        {/* ================= CONTENT ================= */}
        <div className="content-employee"> 
            <div className="favorites">
            <h3>Mine Favoritter</h3>

            <div className="favorite-links">

                <Link key="" href="" target="_blank">
                 
                </Link>
             
            </div>
          </div>
        </div>

      </div>
    </>
  );
}
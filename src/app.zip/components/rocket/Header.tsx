import { getAsset } from "@/utils/getAsset";

export function RocketHeader({ employee }: any) {
  return (
    <div className="header">
      <div className="logo">
        <img src={getAsset("images/rocket-logo.png")} alt="Rocket" />
        <span>by MOONLANDING</span>
      </div>
      <div className="user">
        
        <button className="admin-btn" type="button">
          Employee Dashboard
        </button>
      </div>
    </div>
  );
}

